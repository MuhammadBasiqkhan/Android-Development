package com.example.spinner;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Spinner spin;
    AutoCompleteTextView autotext;
    ArrayList<String> n = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spin =findViewById(R.id.spinnertext);
        autotext = findViewById(R.id.autotext);

        for (int i = 0; i <10 ; i++) {
            n.add("Muhammad Basiq khan");
        }


        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_dropdown_item_1line,n);
        spin.setAdapter(adapter);
        autotext.setAdapter(adapter);
        autotext.setThreshold(1);

    }
}