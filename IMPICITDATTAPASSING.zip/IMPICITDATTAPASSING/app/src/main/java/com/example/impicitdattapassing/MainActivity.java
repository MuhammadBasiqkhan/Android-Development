package com.example.impicitdattapassing;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    Button emailbtn , callbtn , whatsbtn , msgbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailbtn = findViewById(R.id.email);
        callbtn = findViewById(R.id.call);
        whatsbtn= findViewById(R.id.Whats);
        msgbtn= findViewById(R.id.Message);

        emailbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText Msg  ,name;
                Msg= findViewById(R.id.SUBDATA);
                name= findViewById(R.id.Nametext);

                String Message =Msg.getText().toString();
                String username =name.getText().toString();
                Intent iemail = new Intent(Intent.ACTION_SEND);
                iemail.setType("message/rfc822");
                iemail.putExtra(Intent.EXTRA_EMAIL,"khanbasiq16@gmail.com");
                iemail.putExtra(Intent.EXTRA_SUBJECT,username);
                iemail.putExtra(Intent.EXTRA_TEXT,Message);
                startActivity(Intent.createChooser(iemail,"Email via"));



            }
        });


        callbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText name , number ;
                number= findViewById(R.id.numbertext);

                String num = number.getText().toString();

                Intent idial = new Intent(Intent.ACTION_DIAL);
                idial.setData(Uri.parse("tel: "+num));
                startActivity(idial);
            }
        });

        whatsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText Msg;
                Msg= findViewById(R.id.SUBDATA);
                String Message = Msg.getText().toString();
                Intent ishare = new Intent(Intent.ACTION_SEND);
                ishare.setType("text/plain");
                ishare.putExtra(Intent.EXTRA_TEXT, Message);
                startActivity(Intent.createChooser(ishare,"Share via"));

            }
        });

        msgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                EditText Msg ,number ;
                number= findViewById(R.id.numbertext);;
                Msg= findViewById(R.id.SUBDATA);

                String Message =Msg.getText().toString();
                String num =number.getText().toString();

                Intent isend= new Intent(Intent.ACTION_SENDTO);
                isend.setData(Uri.parse("smsto:" +Uri.encode(num)));
                isend.putExtra("sms_body",Message);
                startActivity(isend);
            }
        });
    }
}