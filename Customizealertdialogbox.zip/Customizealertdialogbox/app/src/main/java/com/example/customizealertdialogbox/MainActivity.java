package com.example.customizealertdialogbox;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    Button click;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        click = findViewById(R.id.button);

        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.customalertbox);
                TextView text = dialog.findViewById(R.id.textView3);
                Button order = dialog.findViewById(R.id.button2);
                order.setText("Order");
                text.setText("Order Placed");

                order.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this, "Order Placed Sucessfully", Toast.LENGTH_SHORT).show();
                     dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });
    }
}