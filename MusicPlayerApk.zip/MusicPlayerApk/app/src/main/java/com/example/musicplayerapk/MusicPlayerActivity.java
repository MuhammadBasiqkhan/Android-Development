package com.example.musicplayerapk;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.text.format.Time;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class MusicPlayerActivity extends AppCompatActivity {

    TextView Tittletext, curenttime , Totaltime;
    ImageView pauseplaybtn , previousbtn , nextbtn , Bigmusicicon;
    SeekBar seekbar;

    ArrayList<AudioModel> songslist;
    AudioModel currentSong;


    MediaPlayer mediaplayer = MyMediaPlayer.getInstance();
    int x=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_player);

        Tittletext = findViewById(R.id.Tittletext);
        curenttime = findViewById(R.id.Currenttime);
        Totaltime = findViewById(R.id.Totaltime);
        seekbar = findViewById(R.id.seekbar);
        pauseplaybtn = findViewById(R.id.Pausebtn);
        previousbtn =  findViewById(R.id.previousbtn);
        nextbtn = findViewById(R.id.nextbtn);
        Bigmusicicon = findViewById(R.id.BigMusicIcon);


        Tittletext.setSelected(true);
        songslist = (ArrayList<AudioModel>) getIntent().getSerializableExtra("LIST");
        SetResourceswithMusic();

        MusicPlayerActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(mediaplayer!=null)
                {
                    seekbar.setProgress(mediaplayer.getCurrentPosition());
                    curenttime.setText(convertion(mediaplayer.getCurrentPosition()+""));

                    if(mediaplayer.isPlaying())
                    {
                        pauseplaybtn.setImageResource(R.drawable.baseline_pause_circle_24);

                        Bigmusicicon.setRotation(x++);

                    }
                    else
                    {
                        pauseplaybtn.setImageResource(R.drawable.baseline_play_circle_filled_24);

                        Bigmusicicon.setRotation(0);

                    }
                }
                new Handler().postDelayed(this ,100);
            }
        });


        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if(mediaplayer!=null &&  fromUser)
                {
                    mediaplayer.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }


    void SetResourceswithMusic()
    {

        currentSong = songslist.get(MyMediaPlayer.currentindex);
        Tittletext.setText(currentSong.getTittle());
        Totaltime.setText(convertion(currentSong.getDuration()));

        pauseplaybtn.setOnClickListener(v -> PausePlay());
        previousbtn.setOnClickListener(v -> PlayPreviousSong());
        nextbtn.setOnClickListener(v -> PlayNextSong());

        PlayMusic();

    }

    private void PlayMusic()
    {

        mediaplayer.reset();
        try {

            mediaplayer.setDataSource(currentSong.getPath());
            mediaplayer.prepare();
            mediaplayer.start();
            seekbar.setProgress(0);
            seekbar.setMax(mediaplayer.getDuration());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }
    private void PlayNextSong()
    {
        if(MyMediaPlayer.currentindex==songslist.size()-1)
        {
            return;
        }
        MyMediaPlayer.currentindex +=1;
        mediaplayer.reset();
        SetResourceswithMusic();


    }
    private void PlayPreviousSong()
    {
        if(MyMediaPlayer.currentindex==0)
        {
            return;
        }
        MyMediaPlayer.currentindex -=1;
        mediaplayer.reset();
        SetResourceswithMusic();

    }

    private void PausePlay()
    {

        if(mediaplayer.isPlaying())
        {
            mediaplayer.pause();
        }
        else
        {
            mediaplayer.start();
        }
    }

    public static String convertion(String Druation)
    {
        Long milli = Long.parseLong(Druation);

        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(milli)% TimeUnit.HOURS.toMinutes(1),
                TimeUnit.MILLISECONDS.toSeconds(milli)% TimeUnit.MINUTES.toSeconds(1));



    }
}