package com.example.musicplayerapk;


import android.media.MediaPlayer;

public class MyMediaPlayer {
    static MediaPlayer instance;

    public static int currentindex = -1 ;
    public static MediaPlayer getInstance()
    {
        if(instance == null)
        {
            instance = new MediaPlayer();
        }
        return instance;
    }


}
