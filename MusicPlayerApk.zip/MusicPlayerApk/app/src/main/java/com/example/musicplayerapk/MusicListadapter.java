package com.example.musicplayerapk;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MusicListadapter  extends RecyclerView.Adapter<MusicListadapter.ViewHoldeer>{

    ArrayList<AudioModel> songlist;
    Context context;

    public MusicListadapter(ArrayList<AudioModel> songlist, Context context) {
        this.songlist = songlist;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHoldeer onCreateViewHolder( ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycleritem,parent,false);
        return new MusicListadapter.ViewHoldeer(view);
    }

    @Override
    public void onBindViewHolder(ViewHoldeer holder, int position) {

       AudioModel songdata = songlist.get(position);
       holder.songtittletext.setText(songdata.getTittle());
       holder.songimage.setImageResource(R.drawable.l);

       if(MyMediaPlayer.currentindex==position)
       {
           holder.songtittletext.setTextColor(Color.parseColor("#FF0000"));
       }
       else
       {
           holder.songtittletext.setTextColor(Color.parseColor("#000000"));
       }

       holder.itemView.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               MyMediaPlayer.getInstance().reset();
               MyMediaPlayer.currentindex= position;
               Intent intent= new Intent(context, MusicPlayerActivity.class);
               intent.putExtra("LIST",songlist);
               intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
               context.startActivity(intent);

           }
       });
    }

    @Override
    public int getItemCount() {
        return songlist.size();
    }

    public class ViewHoldeer extends RecyclerView.ViewHolder

    {
        TextView songtittletext;
        ImageView songimage;

        public ViewHoldeer(@NonNull View itemView) {
            super(itemView);

            songtittletext = itemView.findViewById(R.id.SongTittle);
            songimage = itemView.findViewById(R.id.songimage);
        }
    }
}
