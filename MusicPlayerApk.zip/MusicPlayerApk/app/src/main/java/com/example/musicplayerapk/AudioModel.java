package com.example.musicplayerapk;

import java.io.Serializable;

public class AudioModel implements Serializable {
    String Path , Tittle , Duration;

    public AudioModel(String path, String tittle, String duration) {
        Path = path;
        Tittle = tittle;
        Duration = duration;
    }

    public String getPath() {
        return Path;
    }

    public void setPath(String path) {
        Path = path;
    }

    public String getTittle() {
        return Tittle;
    }

    public void setTittle(String tittle) {
        Tittle = tittle;
    }

    public String getDuration() {
        return Duration;
    }

    public void setDuration(String duration) {
        Duration = duration;
    }
}
