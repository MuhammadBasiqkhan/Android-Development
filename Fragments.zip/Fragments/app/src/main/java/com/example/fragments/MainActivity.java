package com.example.fragments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.provider.DocumentsContract;
import android.sax.RootElement;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {



    Button fragA , fragB , fragC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragA=findViewById(R.id.flag1);
        fragB=findViewById(R.id.flag2);
        fragC=findViewById(R.id.flag3);


        int falg =0 ;
        loadFragermt(new fragment() , falg);



        fragA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                fragment fragment = new fragment();
                loadFragermt(fragment, falg);

            }
        });

        fragB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BFragment bFragment = new BFragment();
                loadFragermt(bFragment, 1);
            }
        });

        fragC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CFragment cFragment = new CFragment();
                loadFragermt(cFragment, 1);
            }
        });
    }

    public void loadFragermt(Fragment fragment , int flag)
    {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
/*


        Bundle bundle = new Bundle();

        bundle.putString("arrguemntpass","Muhammad basiq Khan");
        bundle.putInt("arrguemntpass1",114);

        fragment.setArguments(bundle);
*/


        if(flag ==0) {

            ft.add(R.id.container, fragment);
            fm.popBackStack(flag , FragmentManager.POP_BACK_STACK_INCLUSIVE);
            ft.addToBackStack(String.valueOf(flag));

        }
        else
        {
            ft.replace(R.id.container, fragment);
            ft.addToBackStack(null);
        }


        ft.commit();
    }
}