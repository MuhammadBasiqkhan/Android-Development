package com.example.listview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ListAdapter;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
ListView list;
ArrayList<String> arr = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = findViewById(R.id.list);
        //list.toString();

       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");
       arr.add("list.toString()");


        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,arr);

        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position==0)
                {
                    Toast.makeText(MainActivity.this, "Muhammad Basiq Khan", Toast.LENGTH_SHORT).show();
                } else if (position==1)
                {
                    Toast.makeText(MainActivity.this, "Muhammad faiq Khan", Toast.LENGTH_SHORT).show();
                } else if (position==2)
                {
                    Toast.makeText(MainActivity.this, "Muhammad Mussadiq Khan", Toast.LENGTH_SHORT).show();
                }else if (position==3)
                {
                    Toast.makeText(MainActivity.this, "Muhammad Arslan Khan", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}