package com.example.bottomnavigation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {


    BottomNavigationView BN;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BN = findViewById(R.id.navigationbar);


        BN.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {



                int id = item.getItemId();
               if(id==R.id.nav_home )
               {
                 loaffragment(new AFragment() , 0);

               }
               else if (id==R.id.nav_watch) {
                   loaffragment(new BFragment() , 1);

               } else if (id==R.id.nav_friends) {

                   loaffragment(new CFragment() , 1);
               } else if (id==R.id.nav_notification) {

                   loaffragment(new DFragment() , 1);
               }
               else if (id==R.id.nav_Settings) {

                   loaffragment(new EFragment() , 1);
               }

               return true;
            }
        });

        BN.setSelectedItemId(R.id.nav_home);

    }


    public void loaffragment(Fragment fragment ,int i )
    {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction FT = fm.beginTransaction();

        if(i==0) {
            FT.add(R.id.container, fragment);
        }
        else
        {
            FT.replace(R.id.container, fragment);
        }
        FT.commit();
    }
}