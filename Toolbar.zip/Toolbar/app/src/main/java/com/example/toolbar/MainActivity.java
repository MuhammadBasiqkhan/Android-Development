package com.example.toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Toolbar tool ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tool = findViewById(R.id.Toolbar);
        setSupportActionBar(tool);
        if(getSupportActionBar()!=null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Muhammad Basiq Khan");
        }


        tool.setSubtitle("Tooling");





    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        new MenuInflater(this).inflate(R.menu.toolbarmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int newitem = item.getItemId();

        if(newitem == R.id.New)
        {
            Toast.makeText(this, "Created New folder sucessffuly", Toast.LENGTH_SHORT).show();
        }
         else  if(newitem == R.id.save)
        {
            Toast.makeText(this, "Save Sucessfully", Toast.LENGTH_SHORT).show();
        }
           else if(newitem == R.id.copy)
        {
            Toast.makeText(this, "copy data sucessfully", Toast.LENGTH_SHORT).show();
        }
           else if(newitem == R.id.setting)
        {
            Toast.makeText(this, "open Setting in a while", Toast.LENGTH_SHORT).show();
        }
           else
        {
            super.onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }
}