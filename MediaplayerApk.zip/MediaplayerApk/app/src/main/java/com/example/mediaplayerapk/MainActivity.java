package com.example.mediaplayerapk;



import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.CursorWrapper;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.os.PatternMatcher;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private static final int REQ_CODE = 123;
    private static final int REQ_CODE_DATA = 1;
    DrawerLayout drawerLayout;
    NavigationView navview;
    Toolbar tool;
    static ArrayList<Vediofiles> vediofiles = new ArrayList<>();


    ImageButton changeimage;
    ImageView profileimage;
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        navview = findViewById(R.id.navigationdrawer);
        bottomNavigationView = findViewById(R.id.bottomnavview);

        View view = navview.getHeaderView(0);

        changeimage= view.findViewById(R.id.changeimagebtn);
        profileimage = view.findViewById(R.id.profileimage);

        changeimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent icamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(icamera , REQ_CODE_DATA);

            }
        });


        drawerLayout = findViewById(R.id.drawerlay);
        tool = findViewById(R.id.toolbar);
        permisson();

        setSupportActionBar(tool);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this , drawerLayout , tool,
                R.string.Open_drawer, R.string.close_drawer);

        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();







        navview.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemm = item.getItemId();


                if (itemm == R.id.profile)
                {

                    profileFragment pr = new profileFragment();
                    pr.show(getSupportFragmentManager(),pr.getTag());


                }


                else if (itemm==R.id.exit) {
                    AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                    alert.setTitle("Exit");
                    alert.setMessage("Are you sure you want to exit");
                    alert.setIcon(R.drawable.baseline_exit_to_app_24);
                    alert.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finishAffinity();

                        }
                    });
                    alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            Toast.makeText(MainActivity.this, "This will Exit soon ", Toast.LENGTH_SHORT).show();

                        }
                    });
                    alert.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Toast.makeText(MainActivity.this, "Exiting System stop ", Toast.LENGTH_SHORT).show();
                        }
                    });
                    alert.show();

                }


                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });


        loadFragment(new filesFragment() , 0 );

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int itemer = item.getItemId();

                if(itemer==R.id.folder)
                {
                    loadFragment(new filesFragment() , 0 );
                    item.setChecked(true);
                }
                 else if(itemer==R.id.rate)
                {

                    loadFragment(new RateFragment() , 1 );
                    item.setChecked(true);
                }
                 else if(itemer==R.id.list)
                {
                    loadFragment(new dataFragment() , 1 );
                    item.setChecked(true);
                }

                return false;
            }
        });
    }



    public void permisson()
     {
        if(ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE} , REQ_CODE);
        }
        else
        {
            vediofiles = getAllvedios(this);

        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == REQ_CODE)
        {
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED)
            {
                vediofiles = getAllvedios(this);
            }
        }

        else {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE} , REQ_CODE);

        }
    }



    public ArrayList<Vediofiles> getAllvedios(Context context)
    {
        ArrayList<Vediofiles> temp = new ArrayList<>() ;
        Uri uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        String[] projection =  {
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.TITLE,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATE_ADDED,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.DISPLAY_NAME
                        };


        Cursor cursor = context.getContentResolver().query(uri,projection,null , null , null);


        if(cursor !=  null)
        {
            while (cursor.moveToNext()) {


                String id = cursor.getString(0);
                String path = cursor.getString(1);
                String tittle = cursor.getString(2);
                String  size = cursor.getString(3);
                String dateadded = cursor.getString(4);
                String duration = cursor.getString(5);
                String filename = cursor.getString(6);

                Vediofiles vediofiles = new Vediofiles(id , path , tittle , filename , size , dateadded , duration);
                Log.e("error", "path: "+path );
                temp.add(vediofiles);
            }
            cursor.close();
        }
        return temp;

    }







    @Override
    public void onBackPressed() {

        if(drawerLayout.isDrawerOpen(GravityCompat.START))
        {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
           super.onBackPressed();
        }
    }


    public void loadFragment(Fragment fragment, int flag)
    {
androidx.fragment.app.FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();


        if(flag ==0) {

            ft.add(R.id.container, fragment);
            fm.popBackStack(flag , FragmentManager.POP_BACK_STACK_INCLUSIVE);
            ft.addToBackStack(String.valueOf(flag));

        }
        else
        {
            ft.replace(R.id.container, fragment);
            ft.addToBackStack(null);
        }


        ft.commit();

    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK) {
            if (requestCode == REQ_CODE_DATA) {

                Bitmap photo = (Bitmap) data.getExtras().get("data");
                profileimage.setImageBitmap(photo);


            }
        }

    }
}