package com.example.mediaplayerapk;

import static com.example.mediaplayerapk.MainActivity.vediofiles;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public  class VedioAdapter extends RecyclerView.Adapter<VedioAdapter.MyviewHolder> {
    Context context;
    ArrayList<Vediofiles> vediofiles;

    LinearLayout newer ,  sorter;
    View view;

    public VedioAdapter(Context context, ArrayList<Vediofiles> vediofiles) {
        this.context = context;
        this.vediofiles = vediofiles;
    }

    @NonNull
    @Override
    public MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
         view = LayoutInflater.from(context).inflate(R.layout.vedioitem, parent , false);

         MyviewHolder myviewHolder = new MyviewHolder(view);

         return myviewHolder ;
    }

    @Override
    public void onBindViewHolder(@NonNull MyviewHolder holder, int position) {

        holder.filename.setText(vediofiles.get(position).getFilename());
        Glide.with(context).load(vediofiles.get(position).getPath()).into(holder.tumbnail);

       holder.duration.setText(convertion(vediofiles.get(position).getDuration()));


        holder.vedio_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context , VediioiplayerActivity.class);
                intent.putExtra("Filename", vediofiles.get(holder.getAdapterPosition()).getFilename());
                intent.putExtra("filepath" , vediofiles.get(holder.getAdapterPosition()).getPath());
                context.startActivity(intent);
            }
        });



        holder.vedio_item.setOnLongClickListener(new View.OnLongClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public boolean onLongClick(View v) {
                TextView filename , filesize , filepath , filetittle , fileduration ;

                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.filedata);

                filename = dialog.findViewById(R.id.name);
                filepath=  dialog.findViewById(R.id.path);
                filesize = dialog.findViewById(R.id.size);
                filetittle = dialog.findViewById(R.id.tittle);
                fileduration = dialog.findViewById(R.id.duration);

              double fileSizeInMB =  convertsize(vediofiles.get(holder.getAdapterPosition()).getSize());
              String size = String.format("Filesize is: %.2f MB", fileSizeInMB);
                filename.setText("File Name is: "+vediofiles.get(holder.getAdapterPosition()).getFilename());
                filepath.setText("File Path is: "+vediofiles.get(holder.getAdapterPosition()).getPath());
                filesize.setText(size);
                filetittle.setText("File Tittle is: "+vediofiles.get(holder.getAdapterPosition()).getTittle());
                fileduration.setText("File duration is "+convertion(vediofiles.get(holder.getAdapterPosition()).getDuration()));

                dialog.show();

                return false;
            }
        });


        holder.menumore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog = new Dialog(view.getContext());
                dialog.setContentView(R.layout.sortdata);
                newer = dialog.findViewById(R.id.newer);
                sorter = dialog.findViewById(R.id.sorter);

                newer.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(context, "newiest one", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                });

                sorter.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Toast.makeText(context, "sorted as new", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();

                    }
                });

                dialog.show();

            }
        });


    }

    @Override
    public int getItemCount() {
        return vediofiles.size();
    }

    public class MyviewHolder extends RecyclerView.ViewHolder{

       RelativeLayout vedio_item;
        ImageView tumbnail , menumore;
        TextView duration , filename;
        public MyviewHolder(@NonNull View itemView) {
            super(itemView);

            tumbnail = itemView.findViewById(R.id.thumbnail);
            duration = itemView.findViewById(R.id.vedio_duration);
            filename = itemView.findViewById(R.id.vedio_filename);
            menumore = itemView.findViewById(R.id.menu_more);
            vedio_item = itemView.findViewById(R.id.vedio_item);


        }
    }



    public static String convertion(String Druation)
    {
        Long milli = Long.parseLong(Druation);

        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(milli)% TimeUnit.HOURS.toMinutes(1),
                TimeUnit.MILLISECONDS.toSeconds(milli)% TimeUnit.MINUTES.toSeconds(1));



    }


    public static double convertsize(String size)
    {
        long fileSizeInBytes = Long.parseLong(size);
        double fileSizeInMB = (double) fileSizeInBytes / (1024 * 1024);


        return fileSizeInMB;
    }

}
