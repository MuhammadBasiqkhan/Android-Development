package com.example.mediaplayerapk;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class RateFragment extends Fragment {



    private int count =0;
    ImageView first , second , third , fourth , fifth;
    TextView counter;
    public RateFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_rate, container, false);
        first = view.findViewById(R.id.first);
        second = view.findViewById(R.id.Second);
        third = view.findViewById(R.id.Third);
        fourth = view.findViewById(R.id.Fourth);
        fifth = view.findViewById(R.id.Fifth);
        counter = view.findViewById(R.id.count);


      first.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Five_satrrating(first);
          }
      });

      second.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Five_satrrating(second);
          }
      });

      third.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Five_satrrating(third);
          }
      });

      fourth.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Five_satrrating(fourth);
          }
      });

      fifth.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Five_satrrating(fifth);
          }
      });

        return view;
    }




    private void Five_satrrating(ImageView imageView)
    {
        if (imageView.getTag() == null || !imageView.getTag().equals("selected")) {
            imageView.setColorFilter(getResources().getColor(R.color.yellow));
            imageView.setTag("selected");
            count++;
        } else {
            imageView.setColorFilter(null);
            imageView.setTag(null);
            count--;
        }
        updateCounterText();
    }


    private void updateCounterText() {
        if (count == 5) {
            counter.setVisibility(View.VISIBLE);
            counter.setText("5 star rating");
        }
        else
        {
            counter.setVisibility(View.GONE);
        }
    }
}