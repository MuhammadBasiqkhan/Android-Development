package com.example.mediaplayerapk;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import java.util.concurrent.TimeUnit;

public class VediioiplayerActivity extends AppCompatActivity {



    VideoView videoView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        fullScreen();
        setContentView(R.layout.activity_vediioiplayer);

        videoView = findViewById(R.id.play_vedio);
        String filename = getIntent().getStringExtra("Filename");
        String filePath = getIntent().getStringExtra("filepath");


        getSupportActionBar().setSubtitle(filename);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        String videoUrl = filePath;
        Uri videoUri = Uri.parse(videoUrl);
        videoView.setVideoURI(videoUri);
        MediaController mediaController = new MediaController(this);
        videoView.setMediaController(mediaController);
        mediaController.setAnchorView(videoView);

        videoView.start();


        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);



    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int iteme = item.getItemId();

        if(iteme == android.R.id.home)
        {
            onBackPressed();
        }




        return super.onOptionsItemSelected(item);

    }



    public void fullScreen()
    {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

    }



}