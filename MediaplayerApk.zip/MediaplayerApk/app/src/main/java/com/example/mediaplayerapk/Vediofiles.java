package com.example.mediaplayerapk;

public class Vediofiles {
    private String id ;
    private String path ;
    private String tittle ;
    private String filename ;
    private String size ;
    private String  dateadded;
    private String duration ;

    public Vediofiles(String id, String path, String tittle, String filename, String size, String dateadded, String duration) {
        this.id = id;
        this.path = path;
        this.tittle = tittle;
        this.filename = filename;
        this.size = size;
        this.dateadded = dateadded;
        this.duration = duration;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getDateadded() {
        return dateadded;
    }

    public void setDateadded(String dateadded) {
        this.dateadded = dateadded;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
