package com.example.mediaplayerapk;

import static com.example.mediaplayerapk.MainActivity.vediofiles;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class filesFragment extends Fragment {


    RecyclerView recyclerView ;
    public filesFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_files, container, false);

        recyclerView = view.findViewById(R.id.filesid);
        if(vediofiles.size()>0 && vediofiles != null)
        {
            VedioAdapter vedioAdapter = new VedioAdapter(getContext(),vediofiles);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext() , RecyclerView.VERTICAL,false));
            recyclerView.setAdapter(vedioAdapter);

        }






        return  view;
    }
}