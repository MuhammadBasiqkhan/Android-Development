package com.example.notification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;


public class MainActivity extends AppCompatActivity {




    private static final String Notification_String="Channel";
    private static final int Req_Code=100;
    private static final int Notification_ID=100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        Drawable drawable = ResourcesCompat.getDrawable(getResources(),R.drawable.call,null);

        BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;

        Bitmap largeIcon = bitmapDrawable.getBitmap();

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);


        Notification notification;


        Intent intent = new Intent(getApplicationContext() , MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);


        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {

             notification  =  new Notification.Builder(this  )
                     .setContentTitle("Muhammad Basiq Khan")
                    .setLargeIcon(largeIcon)
                    .setSmallIcon(R.drawable.call)
                    .setSubText("Message from Muhammad Basiq Khan")
                    .setChannelId(Notification_String)
                    .build();
            nm.createNotificationChannel(new NotificationChannel(Notification_String , "Name",NotificationManager.IMPORTANCE_HIGH));
        }
        else
        {
            notification  =  new Notification.Builder(this)
              .setContentTitle("Message")
                .setLargeIcon(largeIcon)
                .setSmallIcon(R.drawable.call)
                .setSubText("Yr kia kr rha hai ")
                    .build();
        }


       nm.notify(Notification_ID,notification);

    }
}