package com.example.databseinformation;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "EmployerDB";
    private static final String TABLE_NAME = "EmployerData";
    private static final String KEY_id = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_NUMBER = "phone_number";
    private static final int DATABASE_VERSOIN = 1;


    public DB( Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSOIN);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


          db.execSQL(" CREATE TABLE "+ TABLE_NAME +
                  "(" + KEY_id + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_NAME + " TEXT , " + KEY_NUMBER + " TEXT " + ")" ) ;

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void Insert_Data(String name , String number)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME ,name);
        values.put(KEY_NUMBER , number);
        db.insert(TABLE_NAME ,null , values);

        Log.d("insert", "Insert_Data");

    }

    public ArrayList<Employerdata> Fetch_data()
    {

        SQLiteDatabase db = this.getReadableDatabase();
       Cursor cursor = db.rawQuery(" SELECT * FROM "+ TABLE_NAME , null);

       ArrayList<Employerdata> employerdata = new ArrayList<>();

       while (cursor.moveToNext())
       {

           Employerdata employe = new Employerdata();
           employe.id=cursor.getInt(0);
           employe.name=cursor.getString(1);
           employe.number = cursor.getString(2);

           employerdata.add(employe);

       }

       return employerdata;
    }


    public void Update(Employerdata employerdata)
    {
        SQLiteDatabase database = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NUMBER , employerdata.number);
        values.put(KEY_NAME,employerdata.name);
        database.update(TABLE_NAME , values, KEY_id + " = " + employerdata.id,null);

    }


    public void Delete(int id)
    {
        SQLiteDatabase database = this.getWritableDatabase();

        database.delete(TABLE_NAME, KEY_id+"="+id,null);


    }
}
