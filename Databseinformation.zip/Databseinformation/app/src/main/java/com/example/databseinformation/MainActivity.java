package com.example.databseinformation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText nametext , numbertext;
    Button insert;

    TextView id;
    ArrayList<Employerdata> arr;


    Button update , delete;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nametext = findViewById(R.id.nametext);
        numbertext = findViewById(R.id.numbertext);
      //  data = findViewById(R.id.data_text);
        insert = findViewById(R.id.insert);
        update = findViewById(R.id.update);
        delete = findViewById(R.id.delete);
        id = findViewById(R.id.idtext);



        DB dehelper = new DB(this);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameer = nametext.getText().toString();
                String numberer = numbertext.getText().toString();

                dehelper.Insert_Data(nameer , numberer);
                Toast.makeText(MainActivity.this, "data Isnerted successfully", Toast.LENGTH_SHORT).show();


              
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String nameer = nametext.getText().toString();
                String numberer = numbertext.getText().toString();
                int idtxt = Integer.parseInt(id.getText().toString());
                Employerdata db = new Employerdata();
                db.id=idtxt;
                db.name=nameer;
                db.number=numberer;

                 DB data = new DB(MainActivity.this);
                 data.Update(db);

                Toast.makeText(MainActivity.this, "data updated", Toast.LENGTH_SHORT).show();




            }
        });



        arr = dehelper.Fetch_data();


        for (int i = 0; i <arr.size() ; i++) {

            Log.d("name", "Name is " +arr.get(i).name);

        }





        for (int i = 0; i <arr.size() ; i++) {

            Log.d("number", "Phone Number is " +arr.get(i).number);

        }


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int idtxt = Integer.parseInt(id.getText().toString());
                Employerdata db = new Employerdata();
                db.id=idtxt;

                DB data = new DB(MainActivity.this);
                data.Delete(db.id);


                Toast.makeText(MainActivity.this, "data deleted", Toast.LENGTH_SHORT).show();




            }
        });


    }
}