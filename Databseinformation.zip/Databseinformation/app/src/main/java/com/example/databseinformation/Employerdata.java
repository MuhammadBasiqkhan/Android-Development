package com.example.databseinformation;

public class Employerdata {
    int id ;
    String name , number ;
}
