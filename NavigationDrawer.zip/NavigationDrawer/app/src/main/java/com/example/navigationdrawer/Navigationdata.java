package com.example.navigationdrawer;

public class Navigationdata {
    int id ;
    String name , number ;
}
