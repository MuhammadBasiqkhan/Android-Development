package com.example.navigationdrawer;

import android.app.Dialog;
import android.graphics.Canvas;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import it.xabaras.android.recyclerview.swipedecorator.RecyclerViewSwipeDecorator;

public class AFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    RecyclerView  recyclerView;
    ArrayList<contactmodel> contactarray;
    FloatingActionButton floatbtn;

    Myadapter myadapter;






    public AFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AFragment newInstance(String param1, String param2) {
        AFragment fragment = new AFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View view= inflater.inflate(R.layout.fragment_a, container, false);

        recyclerView = view.findViewById(R.id.recyclerview);
        floatbtn = view.findViewById(R.id.floatingActionButton1);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));



        floatbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Dialog dialog = new Dialog(getContext());
                dialog.setContentView(R.layout.add_update_data);
                EditText name, number;
                Button addbtn;
                name = dialog.findViewById(R.id.nametext);
                number = dialog.findViewById(R.id.numbertext);
                addbtn = dialog.findViewById(R.id.addupdatebtn);

                addbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String nametxt="" , numbertxt="";
                        if(!name.getText().toString().equals("")) {
                             nametxt = name.getText().toString();
                        }
                        else
                        {
                            Toast.makeText(getContext(), "please Enter Tittle", Toast.LENGTH_SHORT).show();
                        }

                        if(!number.getText().toString().equals("")) {
                             numbertxt = "id is "+ number.getText().toString();
                        }

                        else
                        {
                            Toast.makeText(getContext(), "please Enter id", Toast.LENGTH_SHORT).show();
                        }

                        contactarray.add(new contactmodel(R.drawable.baseline_library_books_24,nametxt,numbertxt));
                        myadapter.notifyItemInserted(contactarray.size()-1);

                        recyclerView.scrollToPosition(contactarray.size()-1);

                       dialog.dismiss();


                    }
                });


                dialog.show();
            }
        });

        contactarray= new ArrayList<>();

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());

        // Increase the timeout duration
        int socketTimeout = 30000; // 30 seconds
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET,
                "https://jsonplaceholder.typicode.com/todos",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {


                        Toast.makeText(getContext(), "Receiving data from APi successfully", Toast.LENGTH_SHORT).show();
                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);
                                Log.d("data", "The Response is " + jsonObject.getString("title")+
                                        " The User Id is "+ jsonObject.getInt("id"));


                                String tittle = jsonObject.getString("title");
                                String id ="Id is "+jsonObject.getInt("id");

                                NavigationDB navdb = new NavigationDB(getContext());
                                navdb.Insert_Data(tittle , id);
                                contactarray.add(new contactmodel(R.drawable.baseline_library_books_24 , tittle, id));
                                myadapter = new Myadapter(contactarray);
                                recyclerView.setAdapter(myadapter);

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("error", "onErrorResponse: " + error);
                        Toast.makeText(getContext(), "Something went wrong", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        jsonArrayRequest.setRetryPolicy(policy); // Apply the custom retry policy
        requestQueue.add(jsonArrayRequest);




//        myadapter = new Myadapter(contactarray);
//        recyclerView.setAdapter(myadapter);


        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        return view;
    }

String deletedcontact =null;

    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.START ) {

        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {


            final int position= viewHolder.getAdapterPosition();

            if (direction==ItemTouchHelper.START)
            {
                deletedcontact = String.valueOf(contactarray.get(position).name);
                contactarray.remove(position);
                myadapter.notifyItemRemoved(position);
                Snackbar.make(recyclerView,"Tittle : "+deletedcontact,Snackbar.LENGTH_LONG)
                        .setAction("Undo", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                contactarray.add(position, contactarray.get(position));
                                myadapter.notifyItemInserted(position);

                            }
                        }).show();

            }


        }


        @Override
        public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
            new RecyclerViewSwipeDecorator.Builder(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
                    .addSwipeLeftBackgroundColor(ContextCompat.getColor(getContext(), R.color.pink))
                    .addSwipeLeftActionIcon(R.drawable.baseline_delete_24)
                    .addSwipeLeftLabel("Delete")
                    .create()
                    .decorate();


            super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
        }
    };
}