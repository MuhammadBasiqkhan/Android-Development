package com.example.navigationdrawer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class NavigationDB  extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "NavigatioDB";
    private static final String TABLE_NAME = "Navigationdata";
    private static final String KEY_id = "id";
    private static final String KEY_NAME = "Tittle";
    private static final String KEY_NUMBER = "Book_id";
    private static final int DATABASE_VERSOIN = 1;


    public NavigationDB( Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSOIN);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        db.execSQL(" CREATE TABLE "+ TABLE_NAME +
                "(" + KEY_id + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_NAME + " TEXT , " + KEY_NUMBER + " TEXT " + ")" ) ;

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void Insert_Data(String name , String number)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME ,name);
        values.put(KEY_NUMBER , number);
        db.insert(TABLE_NAME ,null , values);

        Log.d("insert", "Insert_Data");



    }

    public ArrayList<Navigationdata> Fetch_data()
    {

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(" SELECT * FROM "+ TABLE_NAME , null);

        ArrayList<Navigationdata> navbar = new ArrayList<>();

        while (cursor.moveToNext())
        {

            Navigationdata employe = new Navigationdata();
            employe.id =cursor.getInt(0);
            employe.name =cursor.getString(1);
            employe.number = cursor.getString(2);


            navbar.add(employe);

        }

        return navbar;
    }
}
