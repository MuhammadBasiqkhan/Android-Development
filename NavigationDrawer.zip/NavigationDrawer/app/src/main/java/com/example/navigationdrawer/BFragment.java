package com.example.navigationdrawer;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class BFragment extends Fragment {

    ArrayList<Navigationdata> nav_api_data;
    public BFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        NavigationDB nav = new NavigationDB(getContext());

        nav_api_data= nav.Fetch_data();

        for (int i = 0; i < nav_api_data.size(); i++) {

            try {
                Log.d("nav", "Data "+nav_api_data.get(i).name);
            }
            catch (Exception e)
            {

                Log.e("error", "Error is "+e );
            }

        }

        return inflater.inflate(R.layout.fragment_b, container, false);
    }
}