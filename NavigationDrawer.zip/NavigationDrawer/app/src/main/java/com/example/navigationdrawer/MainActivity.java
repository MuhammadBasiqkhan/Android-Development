package com.example.navigationdrawer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar tool;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        drawerLayout = findViewById(R.id.drawerlayout);
        navigationView= findViewById(R.id.drawerview);
        tool = findViewById(R.id.toolbar);

        setSupportActionBar(tool);

        ActionBarDrawerToggle togle = new ActionBarDrawerToggle(this , drawerLayout,tool , R.string.OpenDrawer , R.string.CloseDrawer);

        drawerLayout.addDrawerListener(togle);

        togle.syncState();

        loadfragment(new AFragment() , 0);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                int newitem = item.getItemId();

                if(newitem==R.id.profile)
                {

                    loadfragment(new AFragment() , 0);
                } 
                
                else if (newitem == R.id.Setting) {

                    loadfragment(new BFragment() , 1);

                }

                else if (newitem == R.id.theme) {
                    loadfragment(new CFragment() , 1);

                }

                else if (newitem == R.id.Watch) {
                    loadfragment(new DFragment() , 1);

                }

                else if (newitem == R.id.Login) {
                    loadfragment(new EFragment() , 1);

                }

                drawerLayout.closeDrawer(GravityCompat.START);


                return true;
            }
        });

    }

    public void loadfragment(Fragment fragment , int i)
    {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        if(i==0)
        {
            ft.add(R.id.container , fragment);
        }
        else
        {
            ft.replace(R.id.container , fragment);
        }

        ft.commit();

    }

    @Override
    public void onBackPressed() {


        if(drawerLayout.isDrawerOpen(GravityCompat.START))
        {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else
        {

            AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
            alert.setTitle("Exit");
            alert.setMessage("Are you sure you want to exit");
            alert.setIcon(R.drawable.baseline_exit_to_app_24);
            alert.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    MainActivity.super.onBackPressed();

                }
            });
            alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    Toast.makeText(MainActivity.this, "This will Exit soon ", Toast.LENGTH_SHORT).show();

                }
            });
            alert.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(MainActivity.this, "Exiting System stop ", Toast.LENGTH_SHORT).show();
                }
            });
            alert.show();
        }
    }
}