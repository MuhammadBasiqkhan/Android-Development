package com.example.navigationdrawer;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Myadapter extends RecyclerView.Adapter<Myadapter.myviewholder> {

    ArrayList<contactmodel> contaarray;



    public Myadapter(ArrayList<contactmodel> contaarray) {

        this.contaarray = contaarray;
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerrowdata,parent,false);
        return new myviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myviewholder holder, int position) {

      holder.contimag.setImageResource(contaarray.get(position).image);
       holder.contname.setText(contaarray.get(position).name);
       holder.contnum.setText(contaarray.get(position).number);


       holder.linerrow.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Dialog dialog = new Dialog(v.getContext());
               dialog.setContentView(R.layout.bookdata);

               TextView bookname  = dialog.findViewById(R.id.bookname);
               bookname.setText(contaarray.get(holder.getAdapterPosition()).name);

               dialog.show();
           }
       });



        holder.linerrow.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Dialog dialog = new Dialog(v.getContext());
                dialog.setContentView(R.layout.add_update_data);

                EditText name, number;
                Button upbtn;
                TextView uptxt;
                name = dialog.findViewById(R.id.nametext);
                number = dialog.findViewById(R.id.numbertext);
                upbtn = dialog.findViewById(R.id.addupdatebtn);
                uptxt =dialog.findViewById(R.id.addupdattxt);

                uptxt.setText("Update Tittle");
                upbtn.setText("Update");

                name.setText(contaarray.get(holder.getAdapterPosition()).name);
                number.setText(contaarray.get(holder.getAdapterPosition()).number);

                upbtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String nametxt="" , numbertxt="";
                        if(!name.getText().toString().equals("")) {
                            nametxt = name.getText().toString();
                        }
                        else
                        {
                            Toast.makeText(name.getContext(), "please Enter Tittle", Toast.LENGTH_SHORT).show();
                        }

                        if(!number.getText().toString().equals("")) {
                            numbertxt = "id is "+number.getText().toString();
                        }

                        else
                        {
                            Toast.makeText(number.getContext(), "please Enter id", Toast.LENGTH_SHORT).show();
                        }

                        contaarray.set(holder.getAdapterPosition(), new contactmodel(R.drawable.baseline_library_books_24,nametxt,numbertxt));
                        notifyItemChanged(holder.getAdapterPosition());

                        dialog.dismiss();
                    }
                });

                dialog.show();




                return false;
            }
        });




    }

    @Override
    public int getItemCount() {
        return contaarray.size();
    }

    class myviewholder extends RecyclerView.ViewHolder
    {

        ImageView contimag;
        TextView contname , contnum;
        LinearLayout linerrow;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            contimag = itemView.findViewById(R.id.contimage);
            contname= itemView.findViewById(R.id.contaname);
            contnum= itemView.findViewById(R.id.contnum);
            linerrow = itemView.findViewById(R.id.linerrow);





        }


    }
}
